#!/usr/bin/env python3
"""Derive a Motus trace root. Standard library only, no Motus required.

    python3 derive_root.py trace.json

This is ADR-019's recipe written out, not a call into the runtime, so what you
are trusting is the thirty lines below and not a package you did not read.

The canonical form: UTF-8, keys sorted at every depth, no insignificant
whitespace. The root is a chain — each record's digest covers the record with
its own `payload_hash` blanked and the PREVIOUS digest in place, so a record
cannot be moved, removed or reordered without breaking every link after it.

**Reading `records[-1].integrity.payload_hash` is not deriving the root.** That
field agrees with a forgery; the chain does not.
"""
import hashlib
import json
import sys


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def derived_root(doc):
    if doc.get("schema_version") != "3.0.0":
        return None, "below trace schema 3.0.0 the digests do not cover the chain"
    records = doc.get("records") or []
    if not records:
        return None, "no records"
    if records[-1].get("kind") not in ("run_completed", "run_failed",
                                       "run_cancelled"):
        return None, "the stream does not end in a terminal record"

    prev = "sha256:" + hashlib.sha256(canonical({
        "schema_version": doc["schema_version"],
        "run": doc.get("run") or {},
    })).hexdigest()

    for i, record in enumerate(records):
        integrity = record.get("integrity") or {}
        if integrity.get("prev_hash") != prev:
            return None, f"record {i} does not continue the chain"
        payload = dict(record)
        payload["integrity"] = {"payload_hash": None, "prev_hash": prev}
        digest = "sha256:" + hashlib.sha256(canonical(payload)).hexdigest()
        if integrity.get("payload_hash") != digest:
            return None, f"record {i} has been changed since it was sealed"
        prev = digest
    return prev, None


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "trace.json"
    with open(path, encoding="utf-8") as handle:
        root, why = derived_root(json.load(handle))
    if root is None:
        print(f"NO ROOT: {why}")
        raise SystemExit(1)
    print(root)
